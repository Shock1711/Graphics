let slider;
function setup() {
  createCanvas(windowWidth, windowHeight);
  slider = createSlider (0,255,0);
  slider.position(10,10);
  slider.style('width', '80px');

}

function draw() {
  let h = hour();
  let m = minute();
  let s = second();
  let d = day();
  let n = month();
  let y = year();
  let val = slider.value();
  background(val);

  textFont('Rockwell');
  textSize(30);
  textAlign(CENTER, BOTTOM);
  text('Hour: '+h, 150, 250);
  text('Minute: '+m, 150, 275);
  text('Seconds: '+s, 150, 300);
  text('Day: '+d, 150, 225);
  text('Month: '+n, 150, 200);
  text('Year: '+y, 150, 175);
  
  textFont('Georgia');
  textSize(45);
  textAlign(CENTER,LEFT);
  text('Your Days', 150, 75);
  text('Are Numbered.', 190,115)
  
  fill(0);
  
}
